<?php
$conn=mysql_connect("localhost","root","")or die(mysql_error());
$db=mysql_select_db('quiz',$conn)or die(mysql_error());
// $host = "localhost";
// $dbname = "quiz";
// $username = "root";
// $password = "";
 ?>
